<?php
// $dbServername = "13.229.130.155";
// $dbUsername = "homecare";
// $dbPassword = "password123";
// $dbName = "foodculture";

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "C300";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

if (!$conn){
    die(mysqli_error($conn));
}

?> 