<?php

class chatDB {

  // Holds the database connection
  private $dbConn;
  
  private $host = 'localhost';
  
  private $username = 'root';
  
  private $password = '';
  
  public $dbname = 'C300';
  
  //----- ----/

  /**
   * Create's the connection to the database and stores it in the dbConnection
   */
  public function __construct() {
    $this->dbConn = new mysqli($this->host, $this->username, 
        $this->password, $this->dbname);

    if ($this->dbConn->connect_error) {
      die('Connection error.');
    }
  }

  public function getMessages() {
    $messages = array();
    $query = <<<QUERY
        SELECT 
          `chat`.`Message`,
          `chat`.`sent_on`,
          `user`.`UserID`, 
          `user`.`Name`
        FROM `user`
        JOIN `chat`
          ON `chat`.`UserID` = `user`.`UserID`
        WHERE `chat`.`OfferID` = 1
        ORDER BY `sent_on`
QUERY;
    
    // Execute the query
    $resultObj = $this->dbConn->query($query);
    // Fetch all the rows at once.
    while ($row = $resultObj->fetch_assoc()) {
      $messages[] = $row;
    }
    
    return $messages;
  }

  /**
   * Add a new message to the chat table
   * 
   * @param Integer $userId The user who sent the message
   * @param String $message The Actual message
   * @return bool|Integer The last inserted id of success and false on faileur
   */
  public function addMessage($userId, $message) {
    $addResult = false;
    
    $cUserId = (int) $userId;
    // Escape the message with mysqli real escape
    $cMessage = $this->dbConn->real_escape_string($message);
    
    $query = <<<QUERY
      INSERT INTO `chat`(`UserID`, `Message`, `sent_on`, `OfferID`)
      VALUES ({$cUserId}, '{$cMessage}', UNIX_TIMESTAMP()), 1
QUERY;

    $result = $this->dbConn->query($query);
    
    if ($result !== false) {
      // Get the last inserted row id.
      $addResult = $this->dbConn->insert_id;
    } else {
      echo $this->dbConn->error;
    }
    
    return $addResult;
  }

}