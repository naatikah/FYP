<?php 
	include 'dbh.php';
	$dis = $_GET['districtt'];

	if($dis!=""){
		$station = "SELECT * FROM station WHERE DistrictID = $dis";
		$res = mysqli_query($conn, $station) or die (mysql_error($conn));
		echo "<select name='station'>";
		while ($row=mysqli_fetch_assoc($res)){
			echo "<option value='$row[StationID]'>"; echo $row["Station"]; echo "</option>";
		}
		echo "</select>";
	}
?>