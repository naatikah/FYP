

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./style.css">
	<title>Send Newsletter</title>
	<script type="text/javascript">
		        function back() {
            location.href = "ManageUser.php";
        }
	</script>
</head>
<body>
	<div class="container">
		<h2>Send Newsletter</h2>
		<form id="post" action="Send.php" method="POST" enctype="multipart/form-data">
			<div class="form-group">
				<label class="control-label col-sm-2" for="title">Title Email:</label>
				<div class="form-group col-sm-6">
					<input class="form-control" id="title" type="text" name="title" placeholder="Title" required>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="Content">Body Content:</label>
				<div class="form-group col-sm-6">
					<textarea class="form-control" pattern="[A-Za-z0-9 -]+{3000}" rows="12" name="content" id="content"></textarea>
				</div>
			</div>
			<div class="form-group">
				<label class="image-upload" for="attach">Image Attachment: </label>
				<div class="form-group col-sm-6">
					<input class="form-control" type="file" id="fileChooser" name="image" onchange="return ValidateFileUpload()" placeholder="Do a upload image here">
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="link">Link Reference: </label>
				<div class="form-group col-sm-6">
					<input class="form-control" type="text" name="link" placeholder="Insert link reference here">
				</div>
			</div>
                <div class="form-group">
                    <button class="btn btn-default" type="back" onclick="back()">Back</button>
                    <form class="display">
                       <button class="btn btn-warning" name="submit" type="submit">Send Email</button>
                    </form>
                    </div>
                </div>
		
			
		</form>
	</div>

</body>
</html>