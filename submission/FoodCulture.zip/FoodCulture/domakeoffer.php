<?php
	session_start();
	include "dbh.php";
	$bookingid = $_POST['BookingID'];
	$userid = $_SESSION['userid'];
	$comments = $_POST['Comments'];
	$message = "";

    // build sql insert query
	$sql = "INSERT INTO offer(OfferID, StatusID, UserID, BookingID, DistrictID, Comments) VALUES (NULL, 5, $userid, $bookingid, 1, '$comments')";

	$result = mysqli_query($conn,$sql)or die(mysqli_error($conn));

	if($result){
		$message = "Offer made successfully!";
	}
	else{
		$message = "Failed to create user";
	}
	mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
	     header ("Location: paypal.php")
	?>
</body>
</html>