<?php
    include 'dbh.php';

    $id = $_GET['id'];

    $sql = "SELECT * FROM user u, roles r, status s WHERE u.RoleID = r.RoleID AND u.StatusID = s.StatusID AND u.UserID = $id";
    $result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
    if (mysqli_num_rows($result) == 1){
        $row = mysqli_fetch_array($result);
        $id = $row['UserID'];
        $name = $row['Name'];
        $nric = $row['NRIC'];
        $role = $row['Role'];
        $roleid = $row['RoleID'];
        $status = $row['Status'];
        $statusid = $row['StatusID'];
        $email = $row['Email'];
        $phone = $row['Phone'];
        $add = $row['Address'];
        $des = $row['Description'];
    }

    $sql1 = "SELECT * FROM status";
    $result2 = mysqli_query($conn, $sql) or die(mysqli_error($conn));
    while($row = mysqli_fetch_assoc($result2)){
        $arrContent[] = $row;
    }
    mysqli_close($conn);
?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.12/css/all.css">
    <title></title>
    <script type="text/javascript">
        function back() {
            location.href = "ManageUser.php";
        }
    </script>
    <style type="text/css">
        #div1 {
            background-color: #B3B3B3;
        }

        .display,
        .battery {
            display: inline-block;
        }
    </style>
</head>
<body>
<!--     <nav class="navbar navbar-inverse navbar-toggleable-sm bg-inverse fixed-top">
        <div class="container">
            <a class="navbar-brand" href="./index4.html">Food Culture</a>
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="./aboutus.html">About Us</a></li>
                <li class="nav-item"><a class="nav-link" href="./ContactUs.html">Contact Us</a></li>
                <li class="nav-item"><a class="nav-link" href="./Testimonial.html">Testimonial</a></li>
                <li class="nav-item"><a class="nav-link" href="./HowItWorks.html">How It Works</a></li>
                <li class="nav-item"><a class="nav-link" href="./MailingList.html">Mailing List</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Admin</a>
                    <div class="dropdown-menu" aria-labelledby="dropdown01">
                        <a class="dropdown-item" href="./ManageUser.html">Manage User</a>
                        <a class="dropdown-item" href="#">Tourist Register</a>
                    </div>
                <li>
                <li class="nav-item"><a class="nav-link" href="./index.html">Manage Mailing List</a></li>
                <li class="nav-item">
                    <a class="nav-link" href="./index.html">Log Off</a>
                </li>
            </ul>
        </div>
    </nav> --><br><br><br>
    <div class="container">
        <h1>Edit User details</h1>
        <form action="DoUpdate.php?id=<?php echo $id ?>" id="postForm" method="post">
            <div class="form-group">
                <label class="control-label col-sm-2" for="name">Name: </label>
                <div class="form-group col-sm-6">
                    <input class="form-control" id="name" name="name" type="text" value="<?php echo $name ?>" required />
                </div>
            </div>
            <?php
                if($roleid = 2 || $roleid = 1){


            ?>
            <div class="form-group">
                <label class="control-label col-sm-4" for="nric">NRIC: </label>
                <div class="form-group col-sm-4">
                    <input class="form-control" type="text" name="nric" id="nric" value="<?php echo $nric ?>" readonly>
                </div>
            </div>
        <?php } ?>

            <div class="form-group">
                <label class="control-label col-sm-2" for="role">Role: </label>
                <div class="form-group col-sm-4">
                    <input class="form-control" type="text" name="role" id="role" value="<?php echo $role ?>" readonly>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-4" for="Status">Status: </label>
                <div class="form-group col-sm-4">
                    <!-- <input class="form-control" type="text" name="status" id="status" value="<?php echo $status ?>"> -->
                    <select id="status" name="status" class="form-control" required>
<!--                         <option value="<?php echo $statusid ?>"><?php echo $status ?>                         
                        </option> -->
                        <?php 
                            if($statusid = 1){
                                $newid = 2;
                                $status2 = "Inactive";
                            ?>
                            <option value="<?php echo $newid ?>">
                                <?php echo $status2 ?>
                            </option>
                            <?php
                            }
                            if ($statusid = 2) {
                                $newid = 1;
                                $status2 = "Acitve";
                            ?>
                            <option value="<?php echo $newid ?>">
                                <?php echo $status2 ?>
                            </option>
                            <?php
                            }
                        ?>

                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-2" for="email">Email: </label>
                <div class="form-group col-sm-6">
                    <input pattern="\w+@(hotmail|gmail|outlook|live|ymail|yahoo)\.com" class="form-control" id="email" name="email" value="<?php echo $email ?>" type="text" required />
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-4" for="Phone">Phone Number: </label>
                <div class="form-group col-sm-4">
                    <input class="form-control" id="Phone" name="phone" type="text" value="<?php echo $phone ?>" required />
                </div>
            </div>
            <div class="form-group">
                <div class="form-group">
                    <!-- Date input -->
                    <label class="control-label col-sm-2" for="address">Address: </label>
                    <div class="form-group col-sm-6">
                        <input class="form-control" id="address" name="address" value="<?php echo $add ?>" type="text"/>
                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label col-sm-2" for="description">Description: </label>
                    <div class="form-group col-sm-8">
                        <textarea class="form-control" pattern="[A-Za-z0-9 -]+{3000}" rows="12" name="des" id="description"><?php echo $des ?></textarea>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <button class="btn btn-default" type="submit" onclick="back()">Back</button>
                        <form class="display">
                            <button class="btn btn-success" type="submit">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </form>
    </div>
<!--     <footer class="footer" id="div1">
        <div class="container">
            <div class="row">
                <div class="col-3 col-sm-4">
                    <h5>Links</h5>
                    <li><a href="./Index.html">Home</a></li>
                    <li><a href="./AboutUs.html">About Us</a></li>
                    <li><a href="./ContactUs.html">Contact Us</a></li>
                    <li><a href="./TNC.html">Terms & Condition</a></li>
                    <li><a href="./PrivacyPolicies.html">Privacy Policies</a></li>
                    <li><a href="./FAQ.html">FAQ</a></li>
                </div>
                <div class="col-6">
                    <h5>Our Address</h5>
                    <address>
                        131, Smith Avenue Road<br>
                        #04-452,<br>
                        Singapore 650131<br>
                        Sinagpore<br>
                        Phone: +6518273645<br>
                        Fax: +65172637262<br>
                        Email: foodculture@outlook.com
                    </address>
                </div>
                <div class="row justify-content-center">
                    <div class="col-auto">
                        <p>© Copyright 2018 Food Culture</p>
                    </div>
                </div>
            </div>
        </div>
    </footer> -->
    <script src="node_modules/jquery/dist/jquery.min.js"></script>
    <script src="node_modules/tether/dist/js/tether.min.js"></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
</body>
    </html>