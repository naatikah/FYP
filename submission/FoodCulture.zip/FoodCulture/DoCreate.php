<?php
	include 'dbh.php';

	$name = $_POST['name'];
	$nric = $_POST['nric'];
	// $role = $_POST['role'];
	$status = $_POST['status'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$add = $_POST['address'];
	$descrip = $_POST['des'];
	$search = $_POST['search'];
	$dist = $_POST['district'];
	$station = $_POST['station'];
	$pass = 'password';
	$mes = "";

	$sql = "INSERT INTO user(CountryID, RoleID, StatusID, DistrictID, SearchID, StationID, Email, NRIC, Name, Password, Phone, Address, Description, Subscribe) VALUES (NULL, 1 , $status, $dist, $search, $station, '$email', '$nric', '$name','$pass', $phone, '$add', '$descrip', 0)";

	$result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
	if($result){
    $message="User created Successfully!";
	}else{
    $message="Failed to create user";
}
	mysqli_close($conn);
?>	

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php 
		header("Location: ManageUser.php")
	?>
</body>
</html>