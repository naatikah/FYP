<?php
session_start();
include "dbh.php"; 
$id = $_GET['id'];
$query="DELETE FROM item WHERE OfferId='$id'";
$query1= "DELETE FROM offer WHERE OfferId = '$id'";
$result=mysqli_query($conn,$query) or die(mysqli_error($conn));
$result1=mysqli_query($conn,$query1) or die(mysqli_error($conn));
?>

<!DOCTYPE html>
<html>
    <head>
        
        <meta charset="UTF-8">
         
        <title></title>
    </head>
    <body>
    <?php header("Location: viewoffer.php")?>
        
    </body>
</html>