<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
    <title>Food Culture</title>
    <style type="text/css">
        #div1 {
            background-color: #B3B3B3;
        }
    </style>
</head>
<body>
            <nav class="navbar navbar-inverse navbar-toggleable-sm bg-inverse fixed-top">
                    <div class="container">
                        <a class="navbar-brand" href="./Index.php">Food Culture</a>
                        <ul class="navbar-nav">
                            <li class="nav-item"><a class="nav-link" href="./AboutUs.php">About Us</a></li>
                            <li class="nav-item"><a class="nav-link" href="./ContactUs.php">Contact Us</a></li>
                            <li class="nav-item"><a class="nav-link" href="./Testimonial.php">Testimonial</a></li>
                            <li class="nav-item"><a class="nav-link" href="./HowItWorks.php">How It Works</a></li>
                            <li class="nav-item"><a class="nav-link" href="./">Mailing List</a></li>
                            <li class="nav-item"><a class="nav-link" href="./Login.php">Login</a></li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Register</a>
                                <div class="dropdown-menu" aria-labelledby="dropdown01">
                                    <a class="dropdown-item" href="./Hregister.php">Host Register</a>
                                    <a class="dropdown-item" href="./tregister.php">Tourist Register</a>
                                </div>
                            <li>
                        </ul>
                    </div>
                </nav><br><br><br>
    <header class="jumbotron">
        <div class="container">
            <div class="row row-header">
                <div class="col-12 col-sm-8">
                    <h1>Food Culture </h1>
                    <p>Looking for non-touristy things to do in Singapore? Signing up for a Food Culture is a great way to experience the real Singapore. Learn about Singapore food and way of life by visiting homes from all around the country.</p>
                </div>
                <div class="col col-sm">
                    <img class="d-flex ml-3 img-thumbnail alight-self-center" src="imgs/sg-life.jpg" alt="sglife">
                </div>
            </div>
        </div>
    </header>
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<h2>Frequently Asked Questions</h2>
				<hr></hr>
				<br>
				<p class="font-italic">Who are the hosts?</p>
				<p class="font-weight-bold">Local foodie and family volunteers.</p>
				<p>
					Our hosts are from all walks of life, as you can see in these videos. Visit local families just like you with similar age kids, find foodies who will share their knowledge of Japanese culture. Miss your pets back home while traveling? Find a host who loves dogs just like you. They may have studied abroad in your hometown, are learning to speak your mother tongue, or want to share their traditional Japanese tea ceremony or calligraphy skills. You can confirm all these details before booking your Nagomi Visit since all hosts go through a screening process and complete a full profile.
				</p>

				<br>

				<p class="font-italic">How am I matched?</p>
				<p class="font-weight-bold">Both you and the host actively choose.</p>
				<p>
					The Nagomi Visit guest and host matching system is created in a way so that you and the host can actively match yourself with people you both actually want to meet. After you send your request, all hosts registered in the area read the profile information you send. They respond if they can host on the requested dates and times you included but more importantly, purely because they decided they want to meet you based on the details you wrote in your request.
				</p>

				<br>

				<p class="font-italic">Where do the hosts live?</p>
				<p class="font-weight-bold">Less than 1 hour by train from your prefered location, all over Japan.</p>
				<p>
					From high rises in the city center to farm houses surrounded by rice fields, our hosts are located all over Japan from Hokkaido to Okinawa including Tokyo, Kyoto, Osaka, Nagano, Matsumoto, Nagoya, Himeji, Tottori, Hiroshima, and more. Check our map or booking form for the most current locations. Hosts who live less than an hour by public transportation from your selected location will respond to your request. Distance from major train stations can be confirmed before booking and specific locations on where to meet the host will be revealed after payment.
				</p>

				<br>

				<p class="font-italic">How long is a Nagomi Visit?</p>
				<p class="font-weight-bold">Less than 1 hour to home + minimum 2-3 hours at home</p>
				<p>
					All select stations are within an hour by train to the host’s home and at least 2-3 hours is spent at home. Choose dates where you can be flexible with time as a Nagomi Visit is very different from going on a fixed schedule tour or going out for a quick bite. There are many hosts who live in the city center or a few minutes walk from famous tourist attractions. However, for those wanting to take advantage of visiting our hosts who live in more rural areas, travel up to an hour and surround yourself with beautiful rice fields or mountains. Either way it is always better to have enough time for good conversation and any unexpected pre- or post- Nagomi Visit plans with your host. Some are more than happy to take you to see or experience local hidden attractions, even if it is just a quick stop to a local supermarket.
				</p>

			</div>
		</div>
	</div>
	    <footer class="footer" id="div1">
        <div class="container">
            <div class="row">
                <div class="col-3 col-sm-4">
                    <h5>Links</h5>
                    <li><a href="./Index.php">Home</a></li>
                    <li><a href="./AboutUs.php">About Us</a></li>
                    <li><a href="./ContactUs.php">Contact Us</a></li>
                    <li><a href="./TNC.php">Terms & Condition</a></li>
                    <li><a href="./PrivacyPolicies.php">Privacy Policies</a></li>
                    <li><a href="./FAQ.php">FAQ</a></li>
                </div>
                <div class="col-6">
                    <h5>Our Address</h5>
                    <address>
                        131, Smith Avenue Road<br>
                        #04-452,<br>
                        Singapore 650131<br>
                        Sinagpore<br>
                        Phone: +6518273645<br>
                        Fax: +65172637262<br>
                        Email: foodculture@outlook.com
                    </address>
                </div>
                <div class="row justify-content-center">
                    <div class="col-auto">
                        <p>© Copyright 2018 Food Culture</p>
                    </div>
                </div>
            </div>            
        </div>
    </footer>
	<script src="js/query.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>