<!doctype html>
<html>
<head>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
    <title>Food Culture</title>
    <style type="text/css">
        #div1 {
            background-color: #B3B3B3;
        }
    </style>
  <body>
                <nav class="navbar navbar-inverse navbar-toggleable-sm bg-inverse fixed-top">
                    <div class="container">
                        <a class="navbar-brand" href="./Index.php">Food Culture</a>
                        <ul class="navbar-nav">
                            <li class="nav-item"><a class="nav-link" href="./AboutUs.php">About Us</a></li>
                            <li class="nav-item"><a class="nav-link" href="./ContactUs.php">Contact Us</a></li>
                            <li class="nav-item"><a class="nav-link" href="./Testimonial.php">Testimonial</a></li>
                            <li class="nav-item"><a class="nav-link" href="./HowItWorks.php">How It Works</a></li>
                            <li class="nav-item"><a class="nav-link" href="./">Mailing List</a></li>
                            <li class="nav-item"><a class="nav-link" href="./Login.php">Login</a></li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Register</a>
                                <div class="dropdown-menu" aria-labelledby="dropdown01">
                                    <a class="dropdown-item" href="./Hregister.php">Host Register</a>
                                    <a class="dropdown-item" href="./tregister.php">Tourist Register</a>
                                </div>
                            <li>
                        </ul>
                    </div>
                </nav><br><br><br>
    <header class="jumbotron">
        <div class="container">
            <div class="row row-header">
                <div class="col-12 col-sm-8">
                    <h1>Food Culture </h1>
                    <p>Looking for non-touristy things to do in Singapore? Signing up for a Food Culture is a great way to experience the real Singapore. Learn about Singapore food and way of life by visiting homes from all around the country.</p>
                </div>
                <div class="col col-sm">
                    <img class="d-flex ml-3 img-thumbnail alight-self-center" src="imgs/sg-life.jpg" alt="sglife">
                </div>
            </div>
        </div>
    </header>
	<h1>Terms and Condition</h1>
	<hr>
	<div class="container">
		<h2 style="color:brown;">BASIC TERMS</h2>
		<p>Guests under 18 must be accompanied by a supervising adult over 18 years of age to participate in all the programs.</p>
		<br>
		<h2 style="color:brown;">CANCELLATIONS</h2>
		<p>Assume that all members of this community (including the hosts and guests) are involved in all programs to connect with one another in a meaningful way both online and offline. Be considerate and avoid cancellations and arrive on time.
		</p>
	</div>
            <footer class="footer" id="div1">
        <div class="container">
            <div class="row">
                <div class="col-3 col-sm-4">
                    <h5>Links</h5>
                    <li><a href="./Index.php">Home</a></li>
                    <li><a href="./AboutUs.php">About Us</a></li>
                    <li><a href="./ContactUs.php">Contact Us</a></li>
                    <li><a href="./TNC.php">Terms & Condition</a></li>
                    <li><a href="./PrivacyPolicies.php">Privacy Policies</a></li>
                    <li><a href="./FAQ.php">FAQ</a></li>
                </div>
                <div class="col-6">
                    <h5>Our Address</h5>
                    <address>
                        131, Smith Avenue Road<br>
                        #04-452,<br>
                        Singapore 650131<br>
                        Sinagpore<br>
                        Phone: +6518273645<br>
                        Fax: +65172637262<br>
                        Email: foodculture@outlook.com
                    </address>
                </div>
                <div class="row justify-content-center">
                    <div class="col-auto">
                        <p>© Copyright 2018 Food Culture</p>
                    </div>
                </div>
            </div>            
        </div>
    </footer>
</body>
</html>