<?php
    include 'dbh.php';
    $sql = "SELECT * FROM roles WHERE RoleID = 1";
    $result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
    if(mysqli_num_rows($result) == 1){
        $row = mysqli_fetch_array($result);
        $roleid = $row['RoleID'];
        $role = $row['Role'];
    }

    $sql1 = "SELECT * FROM status LIMIT 2";
    $result1 = mysqli_query($conn, $sql1) or die(mysqli_error($conn));
    while ($row=mysqli_fetch_assoc($result1)) {
        $arrContent[] = $row;
    }

    $district = "SELECT * FROM district";
    $res = mysqli_query($conn, $district) or die(mysqli_error($conn));
    while($row=mysqli_fetch_assoc($res)){
        $arrContent1[] = $row;
    }

    $search = "SELECT * FROM search";
    $rest = mysqli_query($conn, $search) or die(mysqli_error($conn));
    while($row=mysqli_fetch_assoc($rest)){
        $arrContent2[] = $row;
    }
?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.12/css/all.css">
    <title></title>
    <script type="text/javascript">
        function chg_dist() {
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.open("GET","ajax.php?districtt="+document.getElementById("districtidd").value,false);
            xmlhttp.send(null);
            // alert(xmlhttp.responseText);

            document.getElementById("stationid").innerHTML=xmlhttp.responseText;
        }
        function back() {
            location.href = "ManageUser.php";
        }
    </script>
    <style type="text/css">
        #div1 {
            background-color: #B3B3B3;
        }

        .display,
        .battery {
            display: inline-block;
        }
    </style>
</head>
<body>
<!--     <nav class="navbar navbar-inverse navbar-toggleable-sm bg-inverse fixed-top">
        <div class="container">
            <a class="navbar-brand" href="./index4.html">Food Culture</a>
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="./aboutus.html">About Us</a></li>
                <li class="nav-item"><a class="nav-link" href="./ContactUs.html">Contact Us</a></li>
                <li class="nav-item"><a class="nav-link" href="./Testimonial.html">Testimonial</a></li>
                <li class="nav-item"><a class="nav-link" href="./HowItWorks.html">How It Works</a></li>
                <li class="nav-item"><a class="nav-link" href="./MailingList.html">Mailing List</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Admin</a>
                    <div class="dropdown-menu" aria-labelledby="dropdown01">
                        <a class="dropdown-item" href="./ManageUser.html">Manage User</a>
                        <a class="dropdown-item" href="#">Tourist Register</a>
                    </div>
                <li>
                <li class="nav-item"><a class="nav-link" href="./index.html">Manage Mailing List</a></li>
                <li class="nav-item">
                    <a class="nav-link" href="./index.html">Log Off</a>
                </li>
            </ul>
        </div>
    </nav> --><br><br><br>
    <div class="container">
        <h1>Edit User details</h1>
        <form action="DoCreate.php" id="postForm" method="post">
            <div class="form-group">
                <label class="control-label col-sm-2" for="name">Name: </label>
                <div class="form-group col-sm-6">
                    <input class="form-control" id="name" name="name" type="text" placeholder="Full Name" required />
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-4" for="nric">NRIC: </label>
                <div class="form-group col-sm-4">
                    <input class="form-control" type="text" name="nric" id="nric" placeholder="NRIC" required>
                </div>
<!--             </div>
            <div class="form-group">
                <label class="control-label col-sm-2" for="role">Role: </label>
                <div class="form-group col-sm-4">
                    <input class="form-control" type="text" name="role" id="role" value="<?php echo $role ?>" readonly>
                </div>
            </div> -->
            <div class="form-group">
                <label class="control-label col-sm-4" for="search">Search:
                </label>
                <div class="form-group col-sm-4">
                    <select id="search" name="search" class="form-control" required>
                        <?php for($b=0;$b<count($arrContent2);$b++){
                            $searchid = $arrContent2[$b]['SearchID'];
                            $search = $arrContent2[$b]['Search'];
                        ?>
                        <option value="<?php echo $searchid ?>"><?php echo $search ?></option>
                        <?php
                        } ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2" for="email">Email: </label>
                <div class="form-group col-sm-6">
                    <input pattern="\w+@(hotmail|gmail|outlook|live|ymail|yahoo)\.com" class="form-control" id="email" name="email" placeholder="Email Address" type="text" required />
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-4" for="Phone">Phone Number: </label>
                <div class="form-group col-sm-4">
                    <input class="form-control" id="Phone" name="phone" type="text" placeholder="Phone Number" required />
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-4" for="district">District:
                </label>
                <div class="form-group col-sm-4">
                    <select id="districtidd" name="district" class="form-control" onChange="chg_dist()" required>
                        <option value="">-- Select --</option>
                        <?php for($a=0;$a<count($arrContent1);$a++){
                            $districtid = $arrContent1[$a]['DistrictID'];
                            $district = $arrContent1[$a]['District'];
                        ?>
                        <option value="<?php echo $districtid ?>"><?php echo $district ?></option>
                        <?php
                        } ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-4" for="district">Station:
                </label>
                <div class="form-group col-sm-4" id="stationid">
                    <select id="station" name="station" class="form-control" required>
                        <option value="">-- Select --</option>
                    </select>
                </div>
            </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="address">Address: </label>
                    <div class="form-group col-sm-6">
                        <input class="form-control" id="address" name="address" placeholder="Address" type="text"/>
                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label col-sm-2" for="description">Description: </label>
                    <div class="form-group col-sm-8">
                        <textarea class="form-control" pattern="[A-Za-z0-9 -]+{3000}" rows="12" name="des" id="description"></textarea>
                    </div>
                </div>
                <div class="form-group">
                <label class="control-label col-sm-4" for="Status">Status: </label>
                <div class="form-group col-sm-4">
                    <select id="status" name="status" class="form-control" required>
                        <?php for($i=0;$i<count($arrContent);$i++){
                            $statusid = $arrContent[$i]['StatusID'];
                            $status = $arrContent[$i]['Status'];
                        ?>
                        <option value="<?php echo $statusid ?>"><?php echo $status ?></option>
                        <?php
                        } ?>
                    </select>
                </div>
            </div>
                <div class="form-group">
                    <button class="btn btn-default" type="back" onclick="back()">Back</button>
                    <form class="display">
                       <button class="btn btn-success" type="submit">Craete</button>
                    </form>
                    </div>
                </div>
        </form>
    </div>
<!--     <footer class="footer" id="div1">
        <div class="container">
            <div class="row">
                <div class="col-3 col-sm-4">
                    <h5>Links</h5>
                    <li><a href="./Index.html">Home</a></li>
                    <li><a href="./AboutUs.html">About Us</a></li>
                    <li><a href="./ContactUs.html">Contact Us</a></li>
                    <li><a href="./TNC.html">Terms & Condition</a></li>
                    <li><a href="./PrivacyPolicies.html">Privacy Policies</a></li>
                    <li><a href="./FAQ.html">FAQ</a></li>
                </div>
                <div class="col-6">
                    <h5>Our Address</h5>
                    <address>
                        131, Smith Avenue Road<br>
                        #04-452,<br>
                        Singapore 650131<br>
                        Sinagpore<br>
                        Phone: +6518273645<br>
                        Fax: +65172637262<br>
                        Email: foodculture@outlook.com
                    </address>
                </div>
                <div class="row justify-content-center">
                    <div class="col-auto">
                        <p>© Copyright 2018 Food Culture</p>
                    </div>
                </div>
            </div>
        </div>
    </footer> -->
    <script src="node_modules/jquery/dist/jquery.min.js"></script>
    <script src="node_modules/tether/dist/js/tether.min.js"></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
</body>
    </html>