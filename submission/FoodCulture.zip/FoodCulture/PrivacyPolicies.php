<!DOCTYPE html>
<html>
  <head>
        <title></title>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
    <title>Food Culture</title>
    <style type="text/css">
        #div1 {
            background-color: #B3B3B3;
        }
    </style>
  </head>
   <nav class="navbar navbar-inverse navbar-toggleable-sm bg-inverse fixed-top">
        <div class="container">
            <a class="navbar-brand" href="./Index.php">Food Culture</a>
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="./AboutUs.php">About Us</a></li>
                <li class="nav-item"><a class="nav-link" href="./ContactUs.php">Contact Us</a></li>
                <li class="nav-item"><a class="nav-link" href="./Testimonial.php">Testimonial</a></li>
                <li class="nav-item"><a class="nav-link" href="./HowItWorks.php">How It Works</a></li>
                <li class="nav-item"><a class="nav-link" href="./">Mailing List</a></li>
                <li class="nav-item"><a class="nav-link" href="./Login.php">Login</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Register</a>
                    <div class="dropdown-menu" aria-labelledby="dropdown01">
                        <a class="dropdown-item" href="./Hregister.php">Host Register</a>
                        <a class="dropdown-item" href="./tregister.php">Tourist Register</a>
                    </div>
                <li>
            </ul>
        </div>
    </nav>
    <header class="jumbotron">
        <div class="container">
            <div class="row row-header">
                <div class="col-12 col-sm-8">
                    <h1>Food Culture </h1>
                    <p>Looking for non-touristy things to do in Singapore? Signing up for a Food Culture is a great way to experience the real Singapore. Learn about Singapore food and way of life by visiting homes from all around the country.</p>
                </div>
                <div class="col col-sm">
                    <img class="d-flex ml-3 img-thumbnail alight-self-center" src="imgs/sg-life.jpg" alt="sglife">
                </div>
            </div>
        </div>
    </header>
   
  	<div class="container">
        <div class="row row-content align-item-center">
            <div class="col col-sm-6">
  	<h1>Food Culture Privacy Policy</h1>
  	<p>Food Culture is concerned about privacy issues and wants you to be familiar with how we collect, use and disclose information. This Privacy Policy describes our practices in connection with information that we collect through the website or mobile application owned and controlled by us from which you are accessing this Privacy Policy (collectively, the Site ). By providing Personal Information to us or using the Site, you agree to the terms and conditions of this Privacy Policy. </p>

  	<p>This policy applies to all information received by Food Culture.</p>

  	<h1>Personal Information</h1>
  	<p>Personal Information We May Collect</p>

<p>“Personal Information” is information that identifies you as an individual or relates to an identifiable person, including:</p>
<ul>
	<li>Account Information. When you sign up for a Food Culture account, we require certain information such as your full name and email address.</li>

	<li>Profile Information. To use certain features within the Site, we may also ask you to complete a profile, which may include your phone number, age, gender, profile picture, description.</li>

	<li>Communications with Food Culture and other Members. When you communicate with Food Culture or use the Site to communicate with other Members, we collect information about your communication and any information you choose to provide.</li>
</ul>
<p>We may use a third-party payment service to process payments made through the Site. If you wish to make a payment through the Site, your Personal Information may be collected by such third party and not by us and will be subject to the third party’s privacy policy, rather than this Privacy Policy. We have no control over, and are not responsible for, this third party’s collection, use and disclosure of your Personal Information. </p>

<p>If you submit any Personal Information relating to other people to us or to our service providers in connection with the Site, you represent that you have the authority to do so and to permit us to use the information in accordance with this Privacy Policy. </p>

<h1>How we may use this personal information</h1>
<p>We may use it to:</p>
<ul>
<li>Provide, maintain and improve the Site.</li>
<li>To respond to your inquiries and fulfill your requests, such as to send you newsletters.</li>
<li>To send you important information regarding the Site, changes to our terms, conditions and policies and other administrative information.</li>
<li>To complete and fulfill your booking, including, for example, to process your payment, communicate with you regarding your booking and provide you with related customer service.</li>
<li>To request feedback and to otherwise contact you about your use of the Site.</li>
<li>To send you marketing communications that we believe may be of interest to you.</li>
<li>To facilitate social sharing functionality.</li>
<li>Monitor and analyze trends, usage and activities in connection with the Site.</li>
<li>Personalize and improve the Site.</li>
<li>As we believe to be necessary or appropriate: (a) under applicable law, including laws outside your country of residence; (b) to comply with legal process; (c) to respond to requests from public and government authorities, including public and government authorities outside your country of residence; (d) to enforce our terms and conditions; (e) to protect our operations or those of any of our affiliates; (f) to protect our rights, privacy, safety or property, and/or that of our affiliates, you or others; and (g) to allow us to pursue available remedies or limit the damages that we may sustain. </li>
</ul>


<h1>How personal information may be disclosed</h1>
<p>Your Personal Information may be disclosed:</p>
<ul>
<li>To our third party service providers who provide services such as website hosting, data analysis, payment processing, booking fulfillment, information technology and related infrastructure provision, customer service, email delivery, auditing services and other similar services. </li>
<li>As we believe to be necessary or appropriate: (a) under applicable law, including laws outside your country of residence; (b) to comply with legal process; (c) to respond to requests from public and government authorities, including public and government authorities outside your country of residence; (d) to enforce our terms and conditions; (e) to protect our operations or those of any of our affiliates; (f) to protect our rights, privacy, safety or property, and/or that of our affiliates, you or others; and (g) to allow us to pursue available remedies or limit the damages that we may sustain</li>
</ul>

<h1>How we may collect other information</h1>
<ul>
<p>We and our third party service providers may collect Other Information in a variety of ways, including: </p>
<li>Through your browser or device: Certain information is collected by most browsers or automatically through your device, such as your Media Access Control (MAC) address, computer type (Windows or Macintosh), screen resolution, operating system name and version, device manufacturer and model, language and Internet browser type and version. We use this information to ensure that the Site functions properly.</li> 
<li>Using Cookies: Cookies are pieces of information stored directly on the computer that you are using. Cookies allow us to collect information such as browser type, time spent on the Site, pages visited, language preferences and other anonymous traffic data. We and our service providers use the information for security purposes, to facilitate navigation, to display information more effectively, and to personalize your experience while visiting the Site, as well as for online tracking purposes. We also use cookies to gather statistical information about the use of the Site in order to continually improve its design and functionality, understand how it is used and assist us with resolving questions about it. Cookies further allow us to select which of our content, advertisements or offers are most likely to appeal to you and display them while you are on the Site. We may also use cookies in online advertising to track responses to our advertisements.</li>
<li>If you do not want information collected through the use of cookies, there is a simple procedure in most browsers that allows you to automatically decline cookies or be given the choice of declining or accepting the transfer to your computer of a particular cookie (or cookies) from a particular site. You may also wish to refer to http://www.allaboutcookies.org. If you choose to decline cookies, you may experience some inconvenience in your use of the Site, and some or all of the features, functionality and promotions available through the Site may not be available to you.</li>
<li>We use Google Analytics, which uses cookies and other, similar technologies to collect information about Site use anonymously and reports website trends, without identifying individual visitors. We also use an enhancement to Google Analytics called "Demographics and Interest Reporting," through which Google provides us with information about Site users' demographics (e.g., age, gender) and interests. This information, which Google may collect by tracking a user's behavior across third-party websites, helps us to learn more about our users. You can learn about Google's practices in connection with this enhanced tracking and opt out of it by visiting https://www.google.com/settings/ads or by downloading the Google Analytics opt-out browser add-on, available at https://tools.google.com/dlpage/gaoptout.</li>
<li>Using pixel tags and similar technologies: Pixel tags (also known as web beacons and clear GIFs) may be used in connection with some Site pages and HTML-formatted email messages to, among other things, track the actions of Site users and email recipients, measure the success of our marketing campaigns and compile statistics about Site usage and response rates.</li>
<li>IP Address: Your IP Address is a number that is automatically assigned to the computer that you are using by your Internet Service Provider. An IP Address may be identified and logged automatically in our server log files whenever a user visits the Site, along with the time of the visit and the page(s) that were visited. We use IP Addresses for purposes such as calculating Site usage levels, helping diagnose server problems and administering the Site. </li>
<li>From you: We collect other information, such as your preferred means of communication, when you voluntarily provide it. Unless combined with Personal Information, this information does not personally identify you. </li>
<li>By aggregating information: Aggregated Personal Information does not personally identify you (for example, we may aggregate Personal Information to calculate the percentage of our users who have a particular telephone area code). </li>
</ul>
<h1>How we may use and disclose other information</h1>
We may use and disclose Other Information for any purpose, except where we are required to do otherwise under applicable law. If we are required to treat Other Information as Personal Information under applicable law, then we may use it for all the purposes for which we use and disclose Personal Information. We may combine Other Information with Personal Information. If we do, we will treat the combined information as Personal Information as long as it is combined. 
<h1>Third Party Sites</h1>
This Privacy Policy does not address, and we are not responsible for, the privacy, information or other practices of any third parties, including any third party operating any site to which this Site contains a link. The inclusion of a link on the Site does not imply endorsement of the linked site by us or by our affiliates. 

<h1>Security</h1>
We are continuously implementing and updating administrative, technical, and physical security measures to help protect your information against unauthorized access, loss, destruction, or alteration. However, the Internet is not a 100% secure environment so we can’t guarantee the security of the transmission or storage of your information. 

<h1>Retention Period</h1>
We will retain your Personal Information for the period necessary to fulfill the purposes outlined in this Privacy Policy unless a longer retention period is required or permitted by law. 

<h1>Jurisdictional Issues</h1>
The Site is controlled and operated by us from Japan and is not intended to subject us to the laws or jurisdiction of any state, country or territory other than that of Japan. 

<h1>Cross-Border Transfer</h1>
Your Personal Information may be stored and processed in any country where we have facilities or in which we engage service providers, and, by using the Site, you consent to the transfer of information to countries outside of your country of residence which may have data protection rules that are different from those of your country. 

<h1>Sensitive information</h1>
We ask that you not send us, and you not disclose, any sensitive Personal Information (e.g., Social Security numbers, information related to racial or ethnic origin, political opinions, religion or other beliefs, health or criminal background) on or through the Site or otherwise to us. 

<h1>Updates to Privacy policies</h1>
We may change this Privacy Policy. The Last Updated legend above indicates when this Privacy Policy was last revised. Any changes will become effective when we post the revised Privacy Policy on the Site. Your use of the Site following these changes means that you accept the revised Privacy Policy. 

<h1>Contact us</h1>If you have any questions about this Privacy Policy, please contact us at foodculture@outlook.com. 

Last updated July 28, 2018

If you have any questions about this Privacy Policy, please contact us at foodculture@outlook.com. 

Last updated July 28, 2018
	</div>
</div>

</div>
<footer class="footer" id="div1">
        <div class="container">
            <div class="row">
                <div class="col-3 col-sm-4">
                    <h5>Links</h5>
                    <li><a href="./Index.php">Home</a></li>
                    <li><a href="./AboutUs.php">About Us</a></li>
                    <li><a href="./ContactUs.php">Contact Us</a></li>
                    <li><a href="./TNC.php">Terms & Condition</a></li>
                    <li><a href="./PrivacyPolicies.php">Privacy Policies</a></li>
                    <li><a href="./FAQ.php">FAQ</a></li>
                </div>
                <div class="col-6">
                    <h5>Our Address</h5>
                    <address>
                        131, Smith Avenue Road<br>
                        #04-452,<br>
                        Singapore 650131<br>
                        Sinagpore<br>
                        Phone: +6518273645<br>
                        Fax: +65172637262<br>
                        Email: foodculture@outlook.com
                    </address>
                </div>
                <div class="row justify-content-center">
                    <div class="col-auto">
                        <p>© Copyright 2018 Food Culture</p>
                    </div>
                </div>
            </div>            
        </div>
    </footer>
    <!-- jQuery first, then Tether, then Bootstrap JS. -->
    <script src="node_modules/jquery/dist/jquery.min.js"></script>
    <script src="node_modules/tether/dist/js/tether.min.js"></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
  </html>