<?php
session_start();
include "dbh.php";
$BID = "";
$BID = $_GET['id'];
$review = "";
$review = isset($_POST['review']) ? $_POST['review'] : "";
$check = "";
$check = isset($_POST['check']) ? $_POST['check'] : "0";

$query = "UPDATE review SET Description = '$review', Allow = '$check' WHERE ReviewID = '$BID'";
$result=mysqli_query($conn,$query)or die(mysqli_error($conn));

$query1= "SELECT * FROM review WHERE ReviewID = '$BID'";
$result1=mysqli_query($conn,$query1)or die(mysqli_error($conn));
while($row=mysqli_fetch_assoc($result1)){
    $bID = $row['BookingID'];
}

if(isset($_POST['submit'])){
    $file = $_FILES['file'];

    $fileName = $_FILES['file']['name'];
    $fileTmpName = $_FILES['file']['tmp_name'];
    $fileSize = $_FILES['file']['size'];
    $fileError = $_FILES['file']['error'];
    $fileType = $_FILES['file']['type'];

    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));

    $allowed = array('gif', 'png', 'bmp', 'jpeg', 'jpg');
    if(in_array($fileActualExt, $allowed)){
        if($fileError === 0){
            if($fileSize < 2000000){
                $imageNameNew = $fileName.".".uniqid("",true).".".$fileActualExt;
                $fileDestination = 'uploads/'.$imageNameNew;
                $query4 = "UPDATE images SET Name = '$imageNameNew' WHERE ReviewID = '$BID'";
                $result4=mysqli_query($conn,$query4)or die(mysqli_error($conn));
                move_uploaded_file($fileTmpName, $fileDestination);
                }
            }else{
                //echo "Your file is too big!";
                //exit();
            }
        }else{
            //echo "There was an error an error uploading your file!";
            //exit();
        }
    }else{
        //echo "You cannot upload files of this type!";
        //exit();
    }
$query3 = "UPDATE booking SET StatusID = 12 WHERE BookingID = '$bID'";
$result3=mysqli_query($conn,$query3)or die(mysqli_error($conn));

?> 
<html>
    <head>
        
        <meta charset="UTF-8">
         
        <title></title>
    </head>
    <body>
   <?php header ("Location: viewoffer.php") ?>
     </body>
</html>