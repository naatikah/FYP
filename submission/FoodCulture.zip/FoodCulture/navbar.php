   <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
   <title>Home</title>

<?php if($_SESSION['role'] == 1) {?>
                    <nav class="navbar navbar-inverse navbar-toggleable-sm bg-inverse fixed-top">
                    <div class="container">
                        <a class="navbar-brand" href="./Index.php">Food Culture</a>
                        <ul class="navbar-nav">
                            <li class="nav-item"><a class="nav-link" href="./AboutUs.php">About Us</a></li>
                            <li class="nav-item"><a class="nav-link" href="./ContactUs.php">Contact Us</a></li>
                            <li class="nav-item"><a class="nav-link" href="./Testimonial.php">Testimonial</a></li>
                            <li class="nav-item"><a class="nav-link" href="./HowItWorks.php">How It Works</a></li>
                            <li class="nav-item"><a class="nav-link" href="./">Mailing List</a></li>
                            <li class="nav-item"><a class="nav-link" href="./">Manage Review</a></li>
                            <li class="nav-item"><a class="nav-link" href="./ManageUser.php">Manage User</a></li>
                            <li class="nav-item"><a class="nav-link" href="./SendEmail.php">Manage Mailing List</a></li>
                        </ul>
                    </div>
                </nav><br><br><br>

    <?php } if($_SESSION['role'] == 2) {?>
                        <nav class="navbar navbar-inverse navbar-toggleable-sm bg-inverse fixed-top">
                    <div class="container">
                        <a class="navbar-brand" href="./Index.php">Food Culture</a>
                        <ul class="navbar-nav">
                            <li class="nav-item"><a class="nav-link" href="./AboutUs.php">About Us</a></li>
                            <li class="nav-item"><a class="nav-link" href="./ContactUs.php">Contact Us</a></li>
                            <li class="nav-item"><a class="nav-link" href="./Testimonial.php">Testimonial</a></li>
                            <li class="nav-item"><a class="nav-link" href="./HowItWorks.php">How It Works</a></li>
                            <li class="nav-item"><a class="nav-link" href="./">Mailing List</a></li>
                            <li class="nac-item"><a class="nav-link" href="./EditHProfile.php"></a>Edit Profile</li>
                            <li class="nac-item"><a class="nav-link" href="./makeoffer.php"></a>Make Offer</li>
                            <li class="nac-item"><a class="nav-link" href="./viewrequest.php"></a>View Request</li>
                        </ul>
                    </div>
                </nav><br><br><br>

        <?php } if($_SESSION['role'] == 3){?>
                        <nav class="navbar navbar-inverse navbar-toggleable-sm bg-inverse fixed-top">
                    <div class="container">
                        <a class="navbar-brand" href="./Index.php">Food Culture</a>
                        <ul class="navbar-nav">
                            <li class="nav-item"><a class="nav-link" href="./AboutUs.php">About Us</a></li>
                            <li class="nav-item"><a class="nav-link" href="./ContactUs.php">Contact Us</a></li>
                            <li class="nav-item"><a class="nav-link" href="./Testimonial.php">Testimonial</a></li>
                            <li class="nav-item"><a class="nav-link" href="./HowItWorks.php">How It Works</a></li>
                            <li class="nav-item"><a class="nav-link" href="./">Mailing List</a></li>
                            <li class="nav-item"><a class="nav-link" href="./EditTProfile.php">Edit Profile</a></li>
                            <li class="nav-item"><a class="nav-link" href="./Booking.php">Make booking</a></li>
                            <li class="nav-item"><a class="nav-link" href="./viewbooking.php">View Booking</a></li>
                            <li class="nav-item"><a class="nav-link" href="./viewoffer.php">View Offer</a></li>
                        </ul>
                    </div>
                </nav><br><br><br>
        <?php }?>