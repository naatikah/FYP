<?php
	include 'dbh.php';

	$id = $_GET['id'];
	$name = $_POST['name'];
	$role = $_POST['role'];
	$status = $_POST['status'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$add = $_POST['address'];
	$des = $_POST['des'];
	$msg = "";

	$sql = "UPDATE user SET  Name = '$name', StatusID = '$status', Email = '$email', Phone = $phone, Address = '$add', Description = '$des' WHERE UserID = $id";

	$result = mysqli_query($conn, $sql) or die (mysqli_error($conn));
	if($result){
		$msg = "User updated successfully!";
	} else {
		$msg = "Error";
	}
	mysqli_close($conn);

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset = "UTF-8">
	<title></title>
</head>
<body>
	<?php header("Location: ManageUser.php") ?>

</body>
</html>