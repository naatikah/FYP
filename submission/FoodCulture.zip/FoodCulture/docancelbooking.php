<?php
session_start();

include ("dbh.php");

$id=$_POST['id'];

$query = "DELETE FROM payment WHERE BookingID = $id";
$result=mysqli_query($conn,$query) or die(mysqli_error($conn));

$query2 = "DELETE FROM images WHERE BookingID = $id";
$result2=mysqli_query($conn,$query2) or die(mysqli_error($conn));

$query1 = "DELETE FROM booking WHERE BookingID = $id";
$result1=mysqli_query($conn,$query1) or die(mysqli_error($conn));



if($result && $result1 && $result2) {
	$msg="Booking has been successfully cancelled!";
	$msg1="<p><a href='viewbooking.php'>Return to View Bookings</p>";
}
else {
	$msg="Booking is not successfully cancelled.";
	$msg1="<p><a href=''>Return to confirming to close page</p>";
}

mysqli_close($conn);

?>
<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <!-- Bootstrap CSS -->
    <!-- build:css css/main.css-->
    <conn rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
    <conn rel="stylesheet" href="node_modules/font-awesome/css/font-awesome.min.css">
    <conn rel="stylesheet" href="css/bootstrap-social.css">
    <conn rel="stylesheet" href="css/styles-old.css">
    <!-- endbuild -->
    <title>Riverside</title>
        
    </head>
    <body>
        <?php header ("Location: viewbooking.php") ?>
    	  </body>
        
</html>