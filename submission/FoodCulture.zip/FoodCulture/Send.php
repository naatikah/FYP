<?php
	include_once 'dbh.php';
	require 'PHPMailer/PHPMailerAutoload.php';
	$fileDestination = "";
	if(isset($_POST['submit'])){
	  $file = $_FILES['image'];

	  $fileName = $_FILES['image']['name'];
	  $fileTmpName = $_FILES['image']['tmp_name'];
	  $fileSize = $_FILES['image']['size'];
	  $fileError = $_FILES['image']['error'];
	  $fileType = $_FILES['image']['type'];

	  $fileExt = explode('.', $fileName);
	  $fileActualExt = strtolower(end($fileExt));

	  $allowed = array('gif', 'png', 'bmp', 'jpeg', 'jpg');
	  if(in_array($fileActualExt, $allowed)){
	    if($fileError === 0){
	      if($fileSize < 2000000){
	        $imageNameNew = $fileName.".".uniqid("",true).".".$fileActualExt;
	        $fileDestination = 'image/'.$imageNameNew;
		    }
		}
	}

		$title = $_POST['title'];
		// $content = $_POST['content'];
		// // $img = $_POST['image'];
		// $link = $_POST['link'];
		

		// $sql = "SELECT * FROM images WHERE Name = $img";
		// $result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
		// if(mysqli_num_rows($result) == 1){
		// 	$row = mysqli_fetch_array($result);
		// 	$name = $row['Name'];
		// }


			$mail = new PHPMailer();
			$mail->Host = "smtp.gmail.com";
			$mail->isSMTP();
			$mail->SMTPAuth = true;
			$mail->Username = "foodculture300@gmail.com";
			$mail->Password = "foodculture2018";
			$mail->SMTPSecure = "ssl";
			$mail->Port = 465;
			$mail->Subject = $title . " ";
			$mail->isHTML(true);
			$mail->Body = " This is my content";
			// "<p>Welcome " . $name "</p> <p>" . $content "</p> <p><a href = '" . $link "'> Click Here! </a></p>";
			$mail->addAttachment ($fileDestination);
			$mail->setFrom('foodculture300@gmail.com', 'foodculture');
			$mail->addAddress('vacksloush@gmail.com');
				if ($mail->send()){
					echo "mail is sent";
				}
				else {
					echo $mail->ErrorInfo;
				}
		
?>

<!-- 	// include_once 'dbh.php';
	// // require 'PHPMailer/PHPMailerAutoload.php';
	// $msg ='';
	// if(isset($_POST['submit'])){
	// 	require 'PHPMailer/PHPMailerAutoload.php';
	// 	$sql = "SELECT * FROM user WHERE subscribe = 1";
	// 	$result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
	// 	while($row = mysqli_fetch_array($result)){
	// 		$arrResult[] = $row;
	// 	}
	// 		function sendemail($to, $from, $fromName, $body, $attachment, $subject){
	// 			$mail = new PHPMailer();
	// 			$mail->Host = "smtp.gmail.com";
	// 			$mail->isSMTP();
	// 			$mail->SMTPAuth = true;
	// 			$mail->setFrom($from, $fromName);
	// 			$mail->addAddress($to);
	// 			$mail->addAttachment($attachment);
	// 			$mail->Subject = $subject;
	// 			$mail->Body = $body;
	// 			$mail->isHTML(false);

	// 			return $mail->send();
	// 		}

	// 		$subject = $_POST['title'];
	// 		$body = $_POST['content'];

	// 		$file = "image/" . basename($_FILES['image']['name']);
	// 		if (move_uploaded_file($_FILES['image']['tmp_name'], $file)){
	// 			if(sendemail($email, 'foodculture300@gmail.com', 'foodculture', $body, $file, $subject)){
	// 				$msg = 'Email sent!';
	// 			}else{
	// 				$msg = 'Email failed!';
	// 			}
	// 		}
	// 		// }else {
	// 		// 	header ("Location: SendEmail.php")
	// 		// 	// $msg = "Please check your attachment!";
	// 		// }
	// 	}

	// } -->

